<?php
require 'config.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// Ensure farmer_id is stored in session
if (!isset($_SESSION['farmer_id'])) {
    // Attempt to fetch farmer_id if not in session, as it might be a direct access after login
    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT id AS farmer_id FROM farmers_ WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $_SESSION['farmer_id'] = $row['farmer_id'];
    } else {
        echo "<script>alert('Erro: Não foi possível encontrar o ID do agricultor.'); window.location.href='../login.php';</script>";
        exit();
    }
    $stmt->close();
}

$farmer_id = $_SESSION['farmer_id']; // Get farmer_id from session
$user_id = $_SESSION['user_id']; // Get user_id from session for profile picture

$profile_picture_path = ''; // Initialize with an empty string

// Fetch farmer's profile picture path from the 'farmers_' table
$stmt_profile = $conn->prepare("SELECT profile_image FROM farmers_ WHERE id = ?");
if ($stmt_profile) {
    $stmt_profile->bind_param("i", $user_id);
    $stmt_profile->execute();
    $result_profile = $stmt_profile->get_result();
    if ($row_profile = $result_profile->fetch_assoc()) {
$profile_picture_path = htmlspecialchars($row_profile['profile_image'] ?? '');
    }
    $stmt_profile->close();
} else {
    error_log("Failed to prepare statement for profile picture in produto.php: " . $conn->error);
}


// Handle product deletion
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Check if the product has been associated with any orders
    $stmt = $conn->prepare("SELECT COUNT(*) AS order_count FROM pedidos_ WHERE farmer_id = ? AND product_id = ?");
    $stmt->bind_param("ii", $farmer_id, $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // If the product is associated with any order
    if ($row['order_count'] > 0) {
        // Alert and redirect back to the same page
        echo "<script>alert('Erro: Este produto não pode ser deletado porque já foi associado a um pedido.');</script>";
        echo "<script>window.location.href = document.referrer;</script>";   // Redirect to the same page
        exit();
    }

    // Proceed to delete the product if no foreign key constraint violation exists
    $stmt = $conn->prepare("DELETE FROM productsz WHERE id = ? AND farmer_id = ?");
    $stmt->bind_param("ii", $id, $farmer_id);

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: produto.php?message=Product+deleted+successfully");
        exit();
    } else {
        $stmt->close();
        header("Location: produto.php?message=Error+deleting+product");
        exit();
    }
}

// Select only products that belong to the logged-in farmer
$sql = "SELECT * FROM productsz WHERE farmer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();

$products = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Agricultor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="produto.css">
</head>

<body>
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="leaf-outline"></ion-icon>
                        </span>
                        <span class="title">Agriapp</span>
                    </a>
                </li>
                <li>
                    <a href="agricultor-dashboard.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Home</span>
                    </a>
                </li>
                <li>
                    <a href="produto.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Produtos</span>
                    </a>
                </li>
                <li>
                    <a href="editar-perfil.php">
                        <span class="icon">
                            <ion-icon name="person-circle-outline"></ion-icon>
                        </span>
                        <span class="title">Editar Perfil</span>
                    </a>
                </li>
                <li>
                    <a href="msg-agricultor.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Mensagens</span>
                    </a>
                </li>


                <li>
                    <a href="logout.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sair</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>

                <div class="search">
                    <label>
                        <input type="text" id="searchInput" placeholder="Pesquisar aqui">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>

                <a href="http://localhost/agriapp/agricultor/editar-perfil.php" style="text-decoration: none;">
    <div class="user" style="cursor: pointer;">
        <?php
            $image_source = '';
            if (!empty($profile_picture_path)) {
                $uploads_dir = 'uploads/';
                if (file_exists($uploads_dir . $profile_picture_path)) {
                    $image_source = $uploads_dir . $profile_picture_path;
                } else {
                    $image_source = 'assets/imgs/default_profile.jpg';
                }
            } else {
                $image_source = 'assets/imgs/default_profile.jpg';
            }
        ?>
        <img src="<?php echo $image_source; ?>" alt="Profile Picture">
    </div>
</a>

            </div>

            <div class="details">
                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Lista de Produtos</h2>
                        <a href="produto-crud.php" class="btn">Adicionar Produto</a>
                    </div>

                    <table class="table table-hover text-center">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Produto</th>
                                <th scope="col">Descrição</th>
                                <th scope="col">Preço</th>
                                <th scope="col">Stock</th>
                                <th scope="col">Imagem</th>
                                <th scope="col">Ação</th>
                            </tr>
                        </thead>
                        <tbody id="productsTableBody">
                            <?php
                            if (!empty($products)) {
                                foreach ($products as $product) {
                                    $imagePath = "../agricultor/uploads/" . htmlspecialchars($product['imagem']??'');
                                    if (!file_exists($imagePath) || empty($product['imagem'])) {
                                        $imagePath = "default.jpg";
                                    }
                                    echo '
                                    <tr>
                                        <td>' . htmlspecialchars($product['id'] ??'') . '</td>
                                        <td>' . htmlspecialchars($product['name'] ?? '') . '</td>
                                        <td>' . htmlspecialchars($product['description'] ?? '') . '</td>
                                        <td>' . htmlspecialchars($product['price'] ?? '') . ' kz</td>
                                        <td>' . htmlspecialchars($product['quantity_avaliable'] ?? '') . '</td>

                                        <td>
                                            <img src="' . $imagePath . '" alt="Product Image" width="50" height="50">
                                        </td>
                                        <td>
                                            <a href="produto-update.php?id=' . $product['id'] . '">
                                                <i class="fas fa-edit fs-5 me-3 edit-data" style="color: black;"></i>
                                            </a>
                                            <a href="#" onclick="confirmDelete(' . $product['id'] . ')">
                                                <i class="fas fa-trash-alt fs-5" style="color: black;"></i>
                                            </a>
                                        </td>
                                    </tr>';
                                }
                            } else {
                                echo '<tr><td colspan="7">Nenhum produto encontrado.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/main.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script>
        // Search Functionality
        const searchInput = document.getElementById("searchInput");
        const productsTableBody = document.getElementById("productsTableBody");

        searchInput.addEventListener("input", function () {
            const searchQuery = this.value.toLowerCase(); // Get the search query in lowercase

            // Loop through all table rows
            Array.from(productsTableBody.getElementsByTagName("tr")).forEach((row) => {
                const rowData = row.textContent.toLowerCase(); // Get the row's text content in lowercase

                // Show/hide the row based on whether it matches the search query
                if (rowData.includes(searchQuery)) {
                    row.style.display = ""; // Show the row
                } else {
                    row.style.display = "none"; // Hide the row
                }
            });
        });

        // Menu Toggle
        let toggle = document.querySelector(".toggle");
        let navigation = document.querySelector(".navigation");
        let main = document.querySelector(".main");

        toggle.onclick = function () {
            navigation.classList.toggle("active");
            main.classList.toggle("active");
        };

        function confirmDelete(productId) {
            // Make an AJAX request to check if the product is deletable
            fetch('check_product_deletable.php?id=' + productId)
                .then(response => response.json())
                .then(data => {
                    if (data.deletable) {
                        // If deletable, confirm with the user before actually deleting
                        if (confirm("Você tem certeza que deseja deletar este produto?")) {
                            window.location.href = "?id=" + productId;
                        }
                    } else {
                        // If not deletable, show the alert message
                        alert("Erro: Este produto não pode ser deletado porque já foi associado a um pedido.");
                    }
                })
                .catch(error => {
                    console.error("Erro ao verificar se o produto pode ser deletado:", error);
                });
        }
    </script>
</body>

</html>