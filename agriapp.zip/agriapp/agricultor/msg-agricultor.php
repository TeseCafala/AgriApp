<?php
session_start();

// Including the configuration file where the database connection is stored
require 'config.php'; // Assuming 'config.php' contains your DB connection setup

// Check if the connection is successfully established
if (!isset($conn)) {
    die("Connection failed: " . mysqli_connect_error());
}

// Verify if the user is logged in and is a farmer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'farmer') {
    echo "<p class='error-message'>Acesso negado. Faça login.</p>";
    exit();
}

date_default_timezone_set('Africa/Luanda'); // Setting timezone to Luanda (UTC+1)

$agricultor_id = $_SESSION['user_id'];
$cliente_id = isset($_GET['cliente_id']) ? intval($_GET['cliente_id']) : null;

// Mark messages as read if client_id is in the URL
if ($cliente_id) {
    if ($stmt = $conn->prepare("UPDATE mensagens SET status = 'lida' WHERE remetente_id = ? AND destinatario_id = ? AND tipo_remetente = 'cliente'")) {
        $stmt->bind_param("ii", $cliente_id, $agricultor_id);
        $stmt->execute();
        $stmt->close();
    } else {
        error_log("Failed to prepare statement for marking messages as read (farmer): " . $conn->error);
    }
}

// Send new message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mensagem'], $_POST['cliente_id'])) {
    $mensagem = trim($_POST['mensagem']);
    $cliente_id_post = intval($_POST['cliente_id']);

    if (!empty($mensagem)) {
        if ($stmt = $conn->prepare("INSERT INTO mensagens (remetente_id, destinatario_id, tipo_remetente, mensagem, status) VALUES (?, ?, 'agricultor', ?, 'nao_lida')")) {
            $stmt->bind_param("iis", $agricultor_id, $cliente_id_post, $mensagem);
            $stmt->execute();
            $stmt->close();

            // Redirect after message submission
            header("Location: msg-agricultor.php?cliente_id=" . $cliente_id_post);
            exit();
        } else {
            error_log("Failed to prepare statement for sending message (farmer): " . $conn->error);
            echo "<p class='error-message'>Erro ao enviar a mensagem. Tente novamente.</p>";
        }
    } else {
        echo "<p class='error-message'>A mensagem não pode estar vazia.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensagens - Agricultor</title>
    <link rel="stylesheet" href="msg-agricultor.css">
</head>
<body>
    <div class="container">
        <h2>Mensagens</h2>

        <div class="sidebar">
            <h4>Clientes:</h4>
            <ul>
                <?php
                // List all clients
                if ($result = $conn->query("SELECT id, name FROM consumer ORDER BY name ASC")):
                    if ($result->num_rows > 0) {
                        while ($cliente = $result->fetch_assoc()):
                            $id_cliente = $cliente['id'];
                            $nome = htmlspecialchars($cliente['name']);
                ?>
                            <li><a href="msg-agricultor.php?cliente_id=<?= $id_cliente ?>" class="<?= ($cliente_id == $id_cliente ? 'active-chat' : '') ?>"><?= $nome ?></a></li>
                <?php
                        endwhile;
                    } else {
                        echo "<li>Nenhum cliente encontrado.</li>";
                    }
                    $result->free(); // Free result set
                else:
                    error_log("Failed to fetch clients: " . $conn->error);
                    echo "<p class='error-message'>Erro ao carregar os clientes.</p>";
                endif;
                ?>
            </ul>
        </div>

        <div class="main-content">
            <?php if ($cliente_id): ?>
                <hr>
                <h4>Conversa com o Cliente #<?= htmlspecialchars($cliente_id) ?></h4>

                <div class="message-history">
                    <?php
                    // Load message history
                    if ($stmt = $conn->prepare("SELECT remetente_id, destinatario_id, tipo_remetente, mensagem, data_envio, status FROM mensagens WHERE (remetente_id = ? AND destinatario_id = ?) OR (remetente_id = ? AND destinatario_id = ?) ORDER BY data_envio ASC")):
                        $stmt->bind_param("iiii", $agricultor_id, $cliente_id, $cliente_id, $agricultor_id);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            while ($msg = $result->fetch_assoc()):
                                $sender = ($msg['tipo_remetente'] === 'agricultor') ? 'Você' : 'Cliente';
                                $message_class = ($msg['tipo_remetente'] === 'agricultor') ? 'sent-message' : 'received-message';
                                $icone_status = ($msg['status'] === 'lida') ? '✔️' : '📭';

                                // Convert date to Angola format
                                $data_envio = date('d/m/Y H:i', strtotime($msg['data_envio']));
                    ?>
                                <div class="message-bubble <?= $message_class ?>">
                                    <strong><?= $sender ?>:</strong> <?= htmlspecialchars($msg['mensagem']) ?>
                                    <small>Enviado em: <?= $data_envio ?> <?= $icone_status ?></small>
                                </div>
                    <?php
                            endwhile;
                        } else {
                            echo "<p class='no-messages'>Nenhuma mensagem nesta conversa ainda. Comece a conversar!</p>";
                        }
                        $stmt->close();
                    else:
                        error_log("Failed to prepare statement for message history (farmer): " . $conn->error);
                        echo "<p class='error-message'>Erro ao carregar o histórico de mensagens.</p>";
                    endif;
                    ?>
                </div>

                <form method="POST" class="message-form">
                    <input type="hidden" name="cliente_id" value="<?= htmlspecialchars($cliente_id) ?>">
                    <textarea name="mensagem" rows="3" placeholder="Digite sua mensagem..." required></textarea>
                    <button type="submit">Enviar</button>
                </form>
            <?php else: ?>
                <p class="select-message">Selecione um cliente à esquerda para iniciar uma conversa.</p>
            <?php endif; ?>
        </div>
    </div>
    <div class="navigation-buttons">
        <button onclick="window.history.back()">Voltar</button>
        <a href="agricultor-dashboard.php" class="button">Voltar para a Dashboard</a>
    </div>
</body>
</html>