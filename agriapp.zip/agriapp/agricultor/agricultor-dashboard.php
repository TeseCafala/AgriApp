<?php
session_start();
require '../config.php'; // Ensure this path is correct relative to agricultor-dashboard.php

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$profile_picture_path = ''; // Initialize with an empty string

// Fetch farmer's profile picture path from the 'farmers_' table
// It's crucial that 'profile_image' column exists in your 'farmers_' table
// Fetch farmer's profile picture path from the 'farmers_' table
$stmt_profile = $conn->prepare("SELECT profile_image FROM farmers_ WHERE id = ?");
if ($stmt_profile) {
    $stmt_profile->bind_param("i", $user_id);
    $stmt_profile->execute();
    $result_profile = $stmt_profile->get_result();
    if ($row_profile = $result_profile->fetch_assoc()) {
        $profile_picture_path = $row_profile['profile_image'] !== null
            ? htmlspecialchars($row_profile['profile_image'])
            : '';
    }
    $stmt_profile->close();
} else {
    error_log("Failed to prepare statement for profile picture: " . $conn->error);
}


// Check if farmer_id is already stored in the session
if (!isset($_SESSION['farmer_id'])) {
    $stmt = $conn->prepare("SELECT id AS farmer_id FROM farmers_ WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $_SESSION['farmer_id'] = $row['farmer_id'];
    } else {
        // This scenario should ideally not happen if login is successful
        // and user_id truly belongs to a farmer.
        echo "<script>alert('Erro: Não foi possível encontrar o ID do agricultor.'); window.location.href='../login.php';</script>";
        exit();
    }
    $stmt->close();
}

$farmer_id = $_SESSION['farmer_id'];

// Handle new order submission (keep this as is)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['product_name'], $_POST['total_value'], $_POST['payment_method'], $_POST['item_count'])) {
        echo "<script>alert('Erro: Dados do pedido ausentes.');</script>";
        exit();
    }

    $product_name = $_POST['product_name'];
    $total_value = (float) $_POST['total_value'];
    $payment_method = $_POST['payment_method'];
    $status = "Completed"; // Assuming new orders are completed by default for this form
    $item_count = (int) $_POST['item_count'];

    $stmt = $conn->prepare("INSERT INTO pedidos_ (user_id, farmer_id, order_date, product_name, total_value, payment_method, status, item_count)
                            VALUES (?, ?, NOW(), ?, ?, ?, ?, ?)");
    $stmt->bind_param("iissdsi", $user_id, $farmer_id, $product_name, $total_value, $payment_method, $status, $item_count);

    if ($stmt->execute()) {
        echo "<script>alert('Pedido criado com sucesso!');</script>";
    } else {
        echo "<script>alert('Erro ao criar o pedido: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}

// Fetch the 10 most recent orders for the current farmer (keep as is)
function getRecentOrders($conn, $farmer_id, $limit = 10) {
    $orders = [];
    $stmt = $conn->prepare("SELECT order_id, user_id, farmer_id, order_date, product_name, total_value, payment_method, status, item_count
                            FROM pedidos_
                            WHERE farmer_id = ?
                            ORDER BY order_date DESC
                            LIMIT ?");
    $stmt->bind_param("ii", $farmer_id, $limit);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $orders[] = $row;
        }
    }
    $stmt->close();
    return $orders;
}

$orders = getRecentOrders($conn, $farmer_id);

// Count total number of orders for the farmer (keep as is)
$orderCount = 0;
$stmt = $conn->prepare("SELECT COUNT(*) AS total_orders FROM pedidos_ WHERE farmer_id = ?");
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $orderCount = $row['total_orders'];
}
$stmt->close();

// --- NEW CODE FOR UNREAD MESSAGE COUNT AND ALERT ---
$unreadMessageCount = 0;
// Query to check for unread messages received by the farmer from clients
$stmt_unread_messages = $conn->prepare("SELECT COUNT(*) AS total_unread_messages FROM mensagens WHERE destinatario_id = ? AND tipo_remetente = 'cliente' AND status = 'nao_lida'");
if ($stmt_unread_messages) {
    $stmt_unread_messages->bind_param("i", $farmer_id);
    $stmt_unread_messages->execute();
    $result_unread_messages = $stmt_unread_messages->get_result();
    if ($row_unread_messages = $result_unread_messages->fetch_assoc()) {
        $unreadMessageCount = $row_unread_messages['total_unread_messages'];
    }
    $stmt_unread_messages->close();
} else {
    error_log("Failed to prepare statement for unread messages: " . $conn->error);
}
// --- END NEW CODE ---


// Count total number of messages sent by the farmer (keep as is, for display on the dashboard card)
$sentMessageCount = 0;
$stmt_sent_messages = $conn->prepare("SELECT COUNT(*) AS total_sent_messages FROM mensagens WHERE remetente_id = ? AND tipo_remetente = 'agricultor'");
if ($stmt_sent_messages) {
    $stmt_sent_messages->bind_param("i", $farmer_id);
    $stmt_sent_messages->execute();
    $result_sent_messages = $stmt_sent_messages->get_result();
    if ($row_sent_messages = $result_sent_messages->fetch_assoc()) {
        $sentMessageCount = $row_sent_messages['total_sent_messages'];
    }
    $stmt_sent_messages->close();
} else {
    error_log("Failed to prepare statement for sent messages: " . $conn->error);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Agricultor</title>
    <link rel="stylesheet" href="agricultor.css">
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</head>
<body>

    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="leaf-outline"></ion-icon>
                        </span>
                        <span class="title">Agriapp</span>
                    </a>
                </li>
                <li>
                    <a href="agricultor-dashboard.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Home</span>
                    </a>
                </li>
                <li>
                    <a href="produto.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Produtos</span>
                    </a>
                </li>
                <li>
                    <a href="editar-perfil.php">
                        <span class="icon">
                            <ion-icon name="person-circle-outline"></ion-icon>
                        </span>
                        <span class="title">Editar Perfil</span>
                    </a>
                </li>
                <li>
                    <a href="msg-agricultor.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Mensagens</span>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sair</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>

                <div class="search">
                    <label>
                        <input type="text" id="searchInput" placeholder="Pesquisar aqui">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>

                <a href="http://localhost/agriapp/agricultor/editar-perfil.php" style="text-decoration: none;">
    <div class="user" style="cursor: pointer;">
        <?php
            $image_source = '';
            if (!empty($profile_picture_path)) {
                $uploads_dir = 'uploads/';
                if (file_exists($uploads_dir . $profile_picture_path)) {
                    $image_source = $uploads_dir . $profile_picture_path;
                } else {
                    $image_source = 'assets/imgs/default_profile.jpg';
                }
            } else {
                $image_source = 'assets/imgs/default_profile.jpg';
            }
        ?>
        <img src="<?php echo $image_source; ?>" alt="Profile Picture">
    </div>
</a>

            </div>

            <div class="cardBox">
                
                <div class="card">
                    <a href="agricultor_vendas.php" style="text-decoration: none;">
                        <div style="flex-grow: 1;">
                            <div class="numbers"><?php echo $orderCount; ?></div>
                            <div class="cardName">Vendas</div>
                        </div>
                        <div class="iconBx">
                            <ion-icon name="cart-outline"></ion-icon>
                        </div>
                    </a>
                </div>

                <div class="card">
                    <a href="msg-agricultor.php" style="text-decoration: none;"> <div style="flex-grow: 1;">
                            <div class="numbers"><?php echo $sentMessageCount; ?></div>
                            <div class="cardName">Mensagens Enviadas</div>
                        </div>
                        <div class="iconBx">
                            <ion-icon name="chatbubbles-outline"></ion-icon>
                        </div>
                    </a>
                </div>
            </div>

            <div class="details">
                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Pedidos Recentes</h2>
                    </div>

                    <table>
                        <thead>
                            <tr>
                                <td>Produto</td>
                                <td>Preço</td>
                                <td>Pagamento</td>
                                <td>Status</td>
                                <td>Data</td>
                            </tr>
                        </thead>

                        <tbody id="ordersTableBody">
                            <?php if (!empty($orders)): ?>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($order['product_name']); ?></td>
                                        <td>Kz <?php echo number_format($order['total_value'], 2, ',', '.'); ?></td>
                                        <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                                        <td>
                                            <span class="status <?php echo strtolower($order['status']); ?>">
                                                <?php echo htmlspecialchars($order['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5">Nenhum pedido encontrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/main.js"></script>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

    <script>
        // Search Functionality
        const searchInput = document.getElementById("searchInput");
        const ordersTableBody = document.getElementById("ordersTableBody");

        searchInput.addEventListener("input", function () {
            const searchQuery = this.value.toLowerCase(); // Get the search query in lowercase

            // Loop through all table rows
            Array.from(ordersTableBody.getElementsByTagName("tr")).forEach((row) => {
                const rowData = row.textContent.toLowerCase(); // Get the row's text content in lowercase

                // Show/hide the row based on whether it matches the search query
                if (rowData.includes(searchQuery)) {
                    row.style.display = ""; // Show the row
                } else {
                    row.style.display = "none"; // Hide the row
                }
            });
        });

        // Menu Toggle
        let toggle = document.querySelector(".toggle");
        let navigation = document.querySelector(".navigation");
        let main = document.querySelector(".main");

        toggle.onclick = function () {
            navigation.classList.toggle("active");
            main.classList.toggle("active");
        };

        // --- NEW JAVASCRIPT FOR ALERT ---
        // This script will only run if $unreadMessageCount is greater than 0
        <?php if ($unreadMessageCount > 0): ?>
            alert("Você tem <?php echo $unreadMessageCount; ?> novas mensagens!");
        <?php endif; ?>
        // --- END NEW JAVASCRIPT ---
    </script>
</body>
</html>