<?php
session_start();
require '../config.php';

// Verifica se está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Pega farmer_id do usuário logado
if (!isset($_SESSION['farmer_id'])) {
    // Correct table name should be 'farmers_' as per your provided schema
    $stmt = $conn->prepare("SELECT id AS farmer_id FROM farmers_ WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $_SESSION['farmer_id'] = $row['farmer_id'];
    } else {
        echo "<script>alert('Erro: Não foi possível encontrar o ID do agricultor.');</script>";
        exit();
    }
    $stmt->close();
}

$farmer_id = $_SESSION['farmer_id'];

// Pega todos os pedidos do agricultor, juntando com os itens do pedido, produtos e dados do consumidor
$sql = "
SELECT
    p.order_id, p.user_id, p.farmer_id, p.order_date, p.product_name, p.total_value, p.status, p.item_count,
    c.name AS consumer_name, -- Corrected: Using 'c.name' from the 'consumer' table
    oi.order_item_id, oi.product_id, oi.quantity, oi.price_at_order,
    pr.name AS product_real_name
FROM pedidos_ p
LEFT JOIN consumer c ON p.user_id = c.id -- Corrected: Joining with the 'consumer' table
LEFT JOIN order_items oi ON p.order_id = oi.order_id
LEFT JOIN productsz pr ON oi.product_id = pr.id
WHERE p.farmer_id = ?
ORDER BY p.order_date DESC, p.order_id DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];

// Vamos organizar os dados para agrupar itens por pedido
while ($row = $result->fetch_assoc()) {
    $order_id = $row['order_id'];

    if (!isset($orders[$order_id])) {
        $orders[$order_id] = [
            'order_id' => $order_id,
            'user_id' => $row['user_id'],
            'farmer_id' => $row['farmer_id'],
            'order_date' => $row['order_date'],
            'product_name' => $row['product_name'],
            'total_value' => $row['total_value'],
            'status' => $row['status'],
            'item_count' => $row['item_count'],
            'consumer_name' => $row['consumer_name'], // Now correctly uses 'consumer_name'
            'items' => []
        ];
    }

    if ($row['order_item_id'] !== null) {
        $orders[$order_id]['items'][] = [
            'order_item_id' => $row['order_item_id'],
            'product_id' => $row['product_id'],
            'product_name' => $row['product_real_name'],
            'quantity' => $row['quantity'],
            'price_at_order' => $row['price_at_order'],
        ];
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <title>Vendas do Agricultor</title>
    <link rel="stylesheet" href="vendas.css" />
</head>
<body>
        <button onclick="history.back()" class="btn-back">Voltar</button>

    <h1>Pedidos do Agricultor</h1>

    <?php if (!empty($orders)): ?>
        <?php foreach ($orders as $order): ?>
            <div class="order-card" style="border:1px solid #ccc; margin-bottom:20px; padding:15px;">
                <h2>Pedido #<?php echo $order['order_id']; ?></h2>
                <p><strong>Data do Pedido:</strong> <?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
                <p><strong>Consumidor:</strong> <?php echo htmlspecialchars($order['consumer_name'] ?: 'N/A'); ?></p> <p><strong>Total de Itens:</strong> <?php echo $order['item_count']; ?></p>
                <p><strong>Valor Total:</strong> Kz <?php echo number_format($order['total_value'], 2, ',', '.'); ?></p>

                <h3>Itens do Pedido:</h3>
                <?php if (!empty($order['items'])): ?>
                    <table border="1" cellpadding="5" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Produto</th>
                                <th>Quantidade</th>
                                <th>Preço unitário na compra</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order['items'] as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>Kz <?php echo number_format($item['price_at_order'], 2, ',', '.'); ?></td>
                                    <td>Kz <?php echo number_format($item['quantity'] * $item['price_at_order'], 2, ',', '.'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Sem itens detalhados para este pedido.</p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Nenhum pedido encontrado.</p>
    <?php endif; ?>


</body>
</html>