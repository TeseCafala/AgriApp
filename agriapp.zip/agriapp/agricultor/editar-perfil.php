<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['farmer_id'])) {
    header('Location: ../login.php');
    exit();
}

$farmer_id = $_SESSION['farmer_id'];

// Buscar dados atuais
$success = '';
$error = '';

$sql = "SELECT * FROM farmers_ WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$result = $stmt->get_result();
$farmer = $result->fetch_assoc();
$stmt->close();


$success = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password_to_save = $farmer['password'];

    if (!empty($_POST['password'])) {
        $password_to_save = password_hash($_POST['password'], PASSWORD_DEFAULT);
    }

    $profile_image = $farmer['profile_image'];
    if (!empty($_FILES['profile_image']['name'])) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $image_name = time() . "_" . basename($_FILES["profile_image"]["name"]);
        $target_file = $target_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $valid_extensions = array("jpg", "jpeg", "png", "gif");
        if (!in_array($imageFileType, $valid_extensions)) {
            $error = "Apenas arquivos JPG, JPEG, PNG e GIF são permitidos.";
        } elseif ($_FILES["profile_image"]["size"] > 500000) {
            $error = "Imagem muito grande.";
        } else {
            if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
                if (!empty($farmer['profile_image']) && $farmer['profile_image'] !== 'default_profile.jpg' && file_exists($target_dir . $farmer['profile_image'])) {
                    unlink($target_dir . $farmer['profile_image']);
                }
                $profile_image = $image_name;
            } else {
                $error = "Erro ao fazer upload da imagem.";
            }
        }
    }

    if (empty($error)) {
        $sql = "UPDATE farmers_ SET name = ?, email = ?, phone = ?, password = ?, profile_image = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $name, $email, $phone, $password_to_save, $profile_image, $farmer_id);

        if ($stmt->execute()) {
            $_SESSION['farmer_name'] = $name;
            $_SESSION['profile_image'] = $profile_image;
            $success = "Perfil atualizado com sucesso!";

            $stmt_re_fetch = $conn->prepare("SELECT * FROM farmers_ WHERE id = ?");
            $stmt_re_fetch->bind_param("i", $farmer_id);
            $stmt_re_fetch->execute();
            $result_re_fetch = $stmt_re_fetch->get_result();
            $farmer = $result_re_fetch->fetch_assoc();
            $stmt_re_fetch->close();
        } else {
            $error = "Erro ao atualizar perfil: " . $stmt->error;
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil - Agricultor</title>
    <link rel="stylesheet" href="agricultor.css">
   <style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background-color: #f0f2f5;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        margin: 0;
        padding: 10px;
    }

    .edit-profile-container {
        background: #ffffff;
        padding: 20px 25px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        max-width: 450px;
        width: 100%;
        box-sizing: border-box;
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
        color: #2E7D32;
        font-size: 22px;
    }

    form {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    label {
        font-weight: 700;
        color: #444;
        font-size: 18px;
    }

    input[type="text"],
    input[type="email"],
    input[type="password"],
    input[type="file"] {
        padding: 10px 12px;
        border-radius: 8px;
        border: 2px solid #ccc;
        font-size: 16px;
    }

    img {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 50%;
        border: 2px solid #4CAF50;
        margin: 10px auto;
        display: block;
    }

    button {
        background-color: #4CAF50;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        margin-top: 10px;
        cursor: pointer;
    }

    button:hover {
        background-color: #45a049;
    }

    .back-button {
        display: block;
        text-align: center;
        margin-top: 15px;
        color: #2E7D32;
        font-weight: 600;
        text-decoration: none;
        font-size: 14px;
    }

    .message, .error {
        padding: 8px;
        border-radius: 6px;
        margin-bottom: 10px;
        text-align: center;
        font-size: 14px;
    }

    .message {
        background: #e6ffe6;
        color: #2E7D32;
    }

    .error {
        background: #ffe6e6;
        color: #c62828;
    }
</style>


</head>
<body>
    <div class="edit-profile-container">
        <h2>Editar Perfil</h2>

        <?php if ($success) echo "<div class='message'>$success</div>"; ?>
        <?php if ($error) echo "<div class='error'>$error</div>"; ?>

        <form method="POST" enctype="multipart/form-data">
            <label for="name">Nome:</label>
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($farmer['name'] ?? '') ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($farmer['email'] ?? '') ?>" required>

            <label for="phone">Telefone:</label>
            <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($farmer['phone'] ?? '') ?>" required>

            <label for="password">Nova Senha (opcional):</label>
            <input type="password" id="password" name="password">

            <label for="profile_image_upload">Foto de Perfil:</label>
            <?php 
                $image_src = 'assets/imgs/default_profile.jpg';
                if (!empty($farmer['profile_image']) && file_exists('uploads/' . $farmer['profile_image'])) {
                    $image_src = 'uploads/' . $farmer['profile_image'];
                }
            ?>
            <img src="<?= $image_src ?>" alt="Imagem de Perfil">
            <input type="file" id="profile_image_upload" name="profile_image">

            <button type="submit">Salvar Alterações</button>
        </form>

        <a href="agricultor-dashboard.php" class="back-button">← Voltar ao Dashboard</a>
    </div>
</body>
</html>
