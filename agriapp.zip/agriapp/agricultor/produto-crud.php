<?php
require 'config.php';
session_start();

// Verificações de sessão
if (!isset($_SESSION['user_id']) || !isset($_SESSION['farmer_id'])) {
    die("<script>alert('Acesso não autorizado.'); window.location.href = '../login.php';</script>");
}

$farmer_id = $_SESSION['farmer_id'];
$errors = [];
$form_data = ['nome' => '', 'descricao' => '', 'preco' => '', 'quantidade' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $form_data['nome'] = trim($_POST['nome'] ?? '');
    $form_data['descricao'] = trim($_POST['descricao'] ?? '');
    $form_data['preco'] = trim($_POST['preco'] ?? '');
    $form_data['quantidade'] = trim($_POST['quantidade'] ?? '');
    $imagem = null;

    if (empty($form_data['nome'])) {
        $errors[] = "O nome do produto é obrigatório.";
    } elseif (strlen($form_data['nome']) > 100) {
        $errors[] = "O nome do produto não pode exceder 100 caracteres.";
    }

    if (empty($form_data['descricao'])) {
        $errors[] = "A descrição do produto é obrigatória.";
    }

    if (empty($form_data['preco']) || !preg_match('/^\d+(\.\d{1,2})?$/', $form_data['preco']) || $form_data['preco'] <= 0) {
        $errors[] = "Preço inválido.";
    }

    if (empty($form_data['quantidade']) || !ctype_digit($form_data['quantidade']) || $form_data['quantidade'] <= 0) {
        $errors[] = "Quantidade inválida.";
    }

    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        $file_extension = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
        $check = getimagesize($_FILES['imagem']['tmp_name']);
        if ($check === false) $errors[] = "Arquivo inválido.";
        if (!in_array($file_extension, $allowed_types)) $errors[] = "Formato de imagem inválido.";
        if ($_FILES['imagem']['size'] > 2000000) $errors[] = "Imagem excede 2MB.";
    }

    if (empty($errors)) {
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = __DIR__ . '/uploads/';
            if (!file_exists($upload_dir)) mkdir($upload_dir, 0755, true);
            $new_filename = uniqid() . '.' . $file_extension;
            if (move_uploaded_file($_FILES['imagem']['tmp_name'], $upload_dir . $new_filename)) {
                $imagem = $new_filename;
            } else {
                $errors[] = "Erro ao fazer upload.";
            }
        }

        if (empty($errors)) {
            $stmt = $conn->prepare("INSERT INTO productsz 
                (name, quantity_avaliable, description, price, imagem, farmer_id) 
                VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sisdsi", 
                $form_data['nome'], $form_data['quantidade'], $form_data['descricao'],
                $form_data['preco'], $imagem, $farmer_id
            );
            if ($stmt->execute()) {
                echo "<script>alert('Produto cadastrado com sucesso!'); window.location.href = 'produto.php';</script>";
                exit();
            } else {
                $errors[] = "Erro ao cadastrar: " . $conn->error;
            }
        }
    }

    if (!empty($errors)) {
        $msg = implode("\\n", $errors);
        echo "<script>alert('{$msg}');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cadastrar Produto - AgriApp</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #2e7d32;
      --secondary: #a5d6a7;
      --bg: #f4f9f6;
      --white: #fff;
      --gray: #e0e0e0;
      --text: #333;
    }

    body {
      font-family: 'Inter', sans-serif;
      background-color: var(--bg);
      padding: 20px;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      min-height: 100vh;
    }

    .form-container {
      background-color: var(--white);
      padding: 20px 16px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
      max-width: 420px;
      width: 100%;
    }

    h1 {
      color: var(--primary);
      margin-bottom: 15px;
      font-size: 20px;
      text-align: center;
    }

    .form-group {
      margin-bottom: 12px;
    }

    label {
      display: block;
      margin-bottom: 5px;
      font-weight: 600;
      font-size: 14px;
      color: var(--primary);
    }

    input,
    textarea {
      width: 100%;
      padding: 9px 10px;
      border-radius: 5px;
      border: 1px solid var(--gray);
      font-size: 14px;
    }

    textarea {
      resize: vertical;
      min-height: 80px;
    }

    input[type="file"] {
      background-color: #f9f9f9;
      border-style: dashed;
    }

    button {
      width: 100%;
      background-color: var(--primary);
      color: white;
      padding: 12px;
      border: none;
      border-radius: 5px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      transition: background 0.3s;
      margin-top: 8px;
    }

    button:hover {
      background-color: #25672b;
    }

    .back-button {
      display: inline-block;
      margin-top: 10px;
      padding: 10px 18px;
      background-color: #25672b;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      text-align: center;
      transition: all 0.2s ease-in-out;
    }

    .back-button:hover {
      background-color: #2e7d32;
      transform: scale(1.03);
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h1>Cadastro de Produto</h1>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($form_data['nome']) ?>" required>
      </div>

      <div class="form-group">
        <label for="preco">Preço (por kg):</label>
        <input type="number" step="0.01" id="preco" name="preco" value="<?= htmlspecialchars($form_data['preco']) ?>" required>
      </div>

      <div class="form-group">
        <label for="quantidade">Quantidade:</label>
        <input type="number" id="quantidade" name="quantidade" value="<?= htmlspecialchars($form_data['quantidade']) ?>" required>
      </div>

      <div class="form-group">
        <label for="descricao">Descrição:</label>
        <textarea id="descricao" name="descricao" rows="4" required><?= htmlspecialchars($form_data['descricao']) ?></textarea>
      </div>

      <div class="form-group">
        <label for="imagem">Imagem:</label>
        <input type="file" name="imagem" accept="image/*" required>
      </div>

      <button type="submit" name="submit">Cadastrar</button>
      <a href="produto.php" class="back-button">← Voltar</a>
    </form>
  </div>
</body>
</html>
