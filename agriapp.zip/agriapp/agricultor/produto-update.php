<?php
require 'config.php';
session_start();

$errors = [];
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$produto = $descricao = $preco = $stock = $imagem = '';
$successMessage = '';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['farmer_id'])) {
    die("<script>alert('Acesso não autorizado.'); window.location.href='../login.php';</script>");
}

if ($id > 0) {
    $stmt = $conn->prepare("SELECT * FROM productsz WHERE id = ? AND farmer_id = ?");
    $stmt->bind_param("ii", $id, $_SESSION['farmer_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $produto = htmlspecialchars($row["name"]);
        $descricao = htmlspecialchars($row["description"]);
        $preco = htmlspecialchars($row["price"]);
        $stock = htmlspecialchars($row["quantity_avaliable"]);
        $imagem = htmlspecialchars($row["imagem"]);
    } else {
        die("<script>alert('Produto não encontrado ou não pertence a você.'); window.location.href='produto.php';</script>");
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["submit"])) {
    $produto = trim($_POST["nome"] ?? '');
    $descricao = trim($_POST["descricao"] ?? '');
    $preco = trim($_POST["preco"] ?? '');
    $stock = trim($_POST["quantidade"] ?? '');
    $imagem_nome = $imagem;

    if (empty($produto)) {
        $errors[] = "Nome do produto é obrigatório";
    } elseif (strlen($produto) > 100) {
        $errors[] = "Nome do produto não pode exceder 100 caracteres";
    }

    if (empty($descricao)) {
        $errors[] = "Descrição do produto é obrigatória";
    }

    if (empty($preco) || !preg_match('/^\d+(\.\d{1,2})?$/', $preco) || $preco <= 0) {
        $errors[] = "Preço deve ser um número positivo com até 2 casas decimais";
    }

    if (empty($stock) || !ctype_digit($stock) || intval($stock) <= 0) {
        $errors[] = "Quantidade deve ser um número inteiro positivo";
    }

    if (isset($_FILES["imagem"]) && $_FILES["imagem"]["error"] === UPLOAD_ERR_OK) {
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        $file_extension = strtolower(pathinfo($_FILES["imagem"]["name"], PATHINFO_EXTENSION));

        $check = getimagesize($_FILES["imagem"]["tmp_name"]);
        if ($check === false) {
            $errors[] = "Arquivo não é uma imagem válida";
        }

        if (!in_array($file_extension, $allowed_types)) {
            $errors[] = "Apenas JPG, JPEG, PNG e GIF são permitidos";
        }

        if ($_FILES["imagem"]["size"] > 2000000) {
            $errors[] = "Imagem não pode exceder 2MB";
        }

        if (empty($errors)) {
            $upload_dir = __DIR__ . '/uploads/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $imagem_nome = uniqid() . '.' . $file_extension;
            if (!move_uploaded_file($_FILES["imagem"]["tmp_name"], $upload_dir . $imagem_nome)) {
                $errors[] = "Erro ao fazer upload da imagem";
            }
        }
    }

    if (empty($errors)) {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE productsz SET name=?, description=?, price=?, quantity_avaliable=?, imagem=? WHERE id=? AND farmer_id=?");
            $stmt->bind_param("ssdissi", $produto, $descricao, $preco, $stock, $imagem_nome, $id, $_SESSION['farmer_id']);
        } else {
            $stmt = $conn->prepare("INSERT INTO productsz (name, description, price, quantity_avaliable, imagem, farmer_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdssi", $produto, $descricao, $preco, $stock, $imagem_nome, $_SESSION['farmer_id']);
        }

        if ($stmt->execute()) {
            $successMessage = "Produto " . ($id > 0 ? "atualizado" : "cadastrado") . " com sucesso!";
            if ($id === 0) {
                $produto = $descricao = $preco = $stock = $imagem = '';
            }
        } else {
            $errors[] = "Erro ao salvar: " . $conn->error;
        }
        $stmt->close();
    }

    if (!empty($errors)) {
        echo "<script>alert('" . implode("\\n", $errors) . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto - AgriApp</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
       :root {
  --primary: #2e7d32;
  --secondary: #a5d6a7;
  --bg: #f4f9f6;
  --white: #fff;
  --gray: #e0e0e0;
  --text: #333;
}

body {
  font-family: 'Inter', sans-serif;
  background-color: var(--bg);
  padding: 20px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-height: 100vh;
}

.form-container {
  background-color: var(--white);
  padding: 25px 20px;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
  max-width: 450px;
  width: 100%;
}

h1 {
  color: var(--primary);
  margin-bottom: 15px;
  font-size: 20px;
  text-align: center;
}

.form-group {
  margin-bottom: 12px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: 600;
  font-size: 14px;
  color: var(--primary);
}

input,
textarea {
  width: 100%;
  padding: 9px 10px;
  border-radius: 5px;
  border: 1px solid var(--gray);
  font-size: 14px;
}

textarea {
  resize: vertical;
  min-height: 80px;
}

input[type="file"] {
  background-color: #f9f9f9;
  border-style: dashed;
}

button {
  width: 100%;
  background-color: var(--primary);
  color: white;
  padding: 12px;
  border: none;
  border-radius: 5px;
  font-weight: 600;
  font-size: 14px;
  cursor: pointer;
  transition: background 0.3s;
  margin-top: 8px;
}

button:hover {
  background-color: #25672b;
}

img {
  margin-top: 6px;
  max-width: 80px;
  border-radius: 4px;
}

.back-button {
  display: inline-block;
  margin-top: 10px;
  padding: 10px 18px;
  background-color: #25672b;
  color: white;
  text-decoration: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  text-align: center;
  transition: all 0.2s ease-in-out;
}

.back-button:hover {
  background-color: #2e7d32;
  transform: scale(1.03);
}

    </style>
    <script>
        function showSuccessMessage() {
            let message = "<?php echo $successMessage; ?>";
            if (message) {
                alert(message);
                window.location.href = "produto.php";
            }
        }
    </script>
</head>
<body onload="showSuccessMessage()">
<div class="form-container">
    <h1><?php echo empty($id) ? "Adicionar" : "Editar"; ?> Produto</h1>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Nome:</label>
            <input type="text" name="nome" value="<?php echo htmlspecialchars($produto); ?>" required>
        </div>
        <div class="form-group">
            <label>Descrição:</label>
            <textarea name="descricao" required><?php echo htmlspecialchars($descricao); ?></textarea>
        </div>
        <div class="form-group">
            <label>Preço (por kg):</label>
            <input type="number" step="0.01" name="preco" value="<?php echo htmlspecialchars($preco); ?>" required>
        </div>
        <div class="form-group">
            <label>Quantidade:</label>
            <input type="number" name="quantidade" value="<?php echo htmlspecialchars($stock); ?>" required>
        </div>
        <div class="form-group">
            <label>Imagem:</label>
            <input type="file" name="imagem">
            <?php if (!empty($imagem)): ?>
                <img src="uploads/<?php echo $imagem; ?>" alt="Imagem atual">
            <?php endif; ?>
        </div>
        <button type="submit" name="submit">Salvar</button>
        <a href="produto.php" class="back-button">← Voltar</a>
    </form>
</div>
</body>
</html>
