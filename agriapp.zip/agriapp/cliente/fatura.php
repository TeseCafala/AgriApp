<?php
include 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$sql = "SELECT 
            p.order_id, p.order_date, p.total_value, p.item_count, 
            p.payment_method, p.status, f.name AS farmer_name,
            pay.payment_date, pay.amount AS paid_amount, pay.status AS payment_status,
            GROUP_CONCAT(CONCAT(pr.name, ' (', oi.quantity, ' x ', oi.price_at_order, ' kz)') SEPARATOR ', ') AS product_details
        FROM pedidos_ p
        JOIN order_items oi ON p.order_id = oi.order_id
        JOIN productsz pr ON oi.product_id = pr.id
        JOIN farmers_ f ON p.farmer_id = f.id
        LEFT JOIN payments pay ON p.order_id = pay.order_id
        WHERE p.user_id = ?
        GROUP BY p.order_id
        ORDER BY p.order_date DESC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$orders = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $orders[] = $row;
    }
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Recibos</title>
    <link rel="stylesheet" href="fatura.css">
</head>
<body>
<header>
    <div class="nav container">
        <a href="cliente-dashboard.php" class="logo"><span>Agri</span>app</a>
        <input type="text" id="search-input" class="search-box" placeholder="Pesquisar produtos...">
        <nav class="nav-links">
            <a href="produtos.php" class="nav-item">Início</a>
            <a href="fatura.php" class="nav-item">Atividade</a>
            <a href="cliente_editar_perfil.php" class="nav-item">Editar Perfil</a>
            <a href="msg-cliente.php" class="nav-item">Mensagens</a>
            <a href="../agricultor/logout.php" class="logout-btn">Logout</a>
        </nav>
    </div>
</header>

<section class="shop container">
    <h2 class="section-title">Histórico de Pedidos</h2>
    <div class="shop-content">
        <?php if (!empty($orders)) {
            foreach ($orders as $order) {
                echo '
                <div class="product-box" 
                     data-id="' . htmlspecialchars($order['order_id']) . '" 
                     data-date="' . htmlspecialchars($order['order_date']) . '" 
                     data-total="' . htmlspecialchars($order['total_value']) . '" 
                     data-itens="' . htmlspecialchars($order['item_count']) . '" 
                     data-products="' . htmlspecialchars($order['product_details']) . '" 
                     data-pay-method="' . htmlspecialchars($order['payment_method']) . '" 
                     data-status="' . htmlspecialchars($order['status']) . '" 
                     data-farmer="' . htmlspecialchars($order['farmer_name']) . '" 
                     data-pay-date="' . ($order['payment_date'] ?? '') . '" 
                     data-pay-status="' . ($order['payment_status'] ?? '') . '" 
                     data-paid-amount="' . ($order['paid_amount'] ?? '') . '">
                    <div class="img"></div>
                   <div class="content">
    <h3 class="order-id">Pedido #' . htmlspecialchars($order['order_id']) . '</h3>
    <h1 class="data">' . htmlspecialchars($order['order_date']) . '</h1>
    <h2 class="valor">' . htmlspecialchars($order['total_value']) . ' kz</h2>
    <h2 class="itens">' . htmlspecialchars($order['item_count']) . ' itens</h2>
</div>

                </div>';
            }
        } else {
            echo '<p class="text-center">Nenhum pedido encontrado.</p>';
        } ?>
    </div>
</section>

<!-- Modal da Fatura -->
<div class="modal" id="modal">
    <div class="modal-content">
        <span class="close-modal">&times;</span>
        <h2>Detalhes da Fatura</h2>
        <p id="modal-id"></p>
        <p id="modal-date"></p>
        <p id="modal-items"></p>
        <p id="modal-value"></p>
        <p id="modal-pay-method"></p>
        <p id="modal-status"></p>
        <p id="modal-farmer"></p>
        <p id="modal-products"></p>
    </div>
</div>

<script>
    const modal = document.getElementById("modal");
    const modalId = document.getElementById("modal-id");
    const modalDate = document.getElementById("modal-date");
    const modalItems = document.getElementById("modal-items");
    const modalValue = document.getElementById("modal-value");
    const modalPayMethod = document.getElementById("modal-pay-method");
    const modalStatus = document.getElementById("modal-status");
    const modalFarmer = document.getElementById("modal-farmer");
    const modalProducts = document.getElementById("modal-products");
    const closeBtn = document.querySelector(".close-modal");

    document.querySelectorAll(".product-box").forEach(box => {
        box.addEventListener("click", () => {
            modalId.textContent = "ID do Pedido: " + box.dataset.id;
            modalDate.textContent = "Data do Pedido: " + box.dataset.date;
            modalItems.textContent = "Itens: " + box.dataset.itens;
            modalValue.textContent = "Valor Total: " + box.dataset.total + " kz";
            modalPayMethod.textContent = "Forma de Pagamento: " + box.dataset.payMethod;
            modalStatus.textContent = "Estado do Pedido: " + box.dataset.status;
            modalFarmer.textContent = "Agricultor: " + box.dataset.farmer;

            const formattedProducts = box.dataset.products.replace(/, /g, '\n');
            modalProducts.textContent = formattedProducts;

            modal.style.display = "flex";
        });
    });

    closeBtn.onclick = () => modal.style.display = "none";
    window.onclick = event => {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
</script>
</body>
</html>
