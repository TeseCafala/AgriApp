<?php
include 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Buscar agricultores ativos com seus produtos
$sql = "SELECT f.id AS farmer_id, f.name AS farmer_name, f.phone, f.profile_image, 
               p.id AS product_id, p.name AS product_name,
               p.description, p.price, p.imagem
        FROM farmers_ f
        LEFT JOIN productsz p ON f.id = p.farmer_id AND p.ativo = 1
        WHERE f.archived = 0
        ORDER BY f.name ASC";

$result = $conn->query($sql);

$agricultores = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $farmer_id = $row['farmer_id'];
        $agricultores[$farmer_id]['nome'] = $row['farmer_name'];
        $agricultores[$farmer_id]['telefone'] = $row['phone'];
        $agricultores[$farmer_id]['foto'] = (!empty($row['profile_image']) && file_exists("../agricultor/uploads/" . $row['profile_image']))
            ? "../agricultor/uploads/" . $row['profile_image']
            : "default_profile.png";

        if (!empty($row['product_id'])) {
            $agricultores[$farmer_id]['produtos'][] = [
                'id' => $row['product_id'],
                'name' => $row['product_name'],
                'description' => $row['description'],
                'price' => $row['price'],
                'imagem' => $row['imagem']
            ];
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Agricultores - AgriApp</title>
    <link rel="stylesheet" href="produtos.css">
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <style>
        .farmer-section {
            margin-bottom: 40px;
        }

        .farmer-header {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            gap: 12px;
        }

        .farmer-header img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #2E7D32;
        }

        .farmer-header .farmer-info {
            display: flex;
            flex-direction: column;
        }

        .farmer-header .farmer-info span {
            font-size: 1.2rem;
            color: #2E7D32;
            font-weight: bold;
        }

        .farmer-header .farmer-info small {
            font-size: 0.9rem;
            color: #555;
        }

        .farmer-products {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }

        .farmer-products .product-box {
            background: #fff;
            padding: 12px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 280px;
            transition: transform 0.2s ease;
        }

        .farmer-products .product-box:hover {
            transform: translateY(-5px);
        }

        .farmer-products .product-img {
            width: 100%;
            height: 140px;
            object-fit: contain;
            border-radius: 6px;
            background-color: #f9f9f9;
        }

        .product-title {
            font-size: 15px;
            font-weight: bold;
            margin: 8px 0 4px;
        }

        .product-description {
            font-size: 13px;
            color: #555;
            flex-grow: 1;
            margin-bottom: 5px;
        }

        .product-price {
            font-size: 14px;
            margin: 6px 0;
            color: #2E7D32;
            font-weight: 600;
        }

        .container {
            max-width: 1100px;
            margin: 20px auto;
            padding: 0 15px;
        }

        h1 {
            font-size: 1.6rem;
            margin: 20px 0;
        }
    </style>
</head>
<body>
<header>
    <div class="nav container">
        <a href="produtos.php" class="logo"><span>Agri</span>app</a>
        <nav class="nav-links">
            <a href="produtos.php" class="nav-item">Início</a>
            <a href="fatura.php" class="nav-item">Atividade</a>
            <a href="msg-cliente.php" class="nav-item">Mensagens</a>
            <a href="cliente_editar_perfil.php" class="nav-item">Editar Perfil</a>
            <a href="agricultores.php" class="nav-item active">Agricultores</a>
            <a href="../agricultor/logout.php" class="logout-button">Logout</a>
        </nav>
    </div>
</header>

<main class="container">
    <h1>Agricultores Cadastrados</h1>
    <?php if (!empty($agricultores)): ?>
        <?php foreach ($agricultores as $agricultor): ?>
            <div class="farmer-section">
                <div class="farmer-header">
                    <img src="<?= htmlspecialchars($agricultor['foto']) ?>" alt="Foto do Agricultor">
                    <div class="farmer-info">
                        <span><?= htmlspecialchars($agricultor['nome']) ?></span>
                        <small>📞 <?= htmlspecialchars($agricultor['telefone']) ?></small>
                    </div>
                </div>

                <?php if (!empty($agricultor['produtos'])): ?>
                    <div class="farmer-products">
                        <?php foreach ($agricultor['produtos'] as $produto):
                            $imagePath = "../agricultor/uploads/" . htmlspecialchars($produto['imagem']);
                            if (empty($produto['imagem']) || !file_exists($imagePath)) {
                                $imagePath = "default.jpg";
                            }
                        ?>
                            <div class="product-box">
                                <img src="<?= $imagePath ?>" alt="<?= htmlspecialchars($produto['name']) ?>" class="product-img">
                                <h3 class="product-title"><?= htmlspecialchars($produto['name']) ?></h3>
                                <p class="product-description"><?= htmlspecialchars($produto['description']) ?></p>
                                <span class="product-price">Kz <?= number_format((float)$produto['price'], 2, ',', '.') ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p style="margin-left: 10px;">Este agricultor ainda não cadastrou produtos.</p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Nenhum agricultor encontrado.</p>
    <?php endif; ?>
</main>
</body>
</html>
