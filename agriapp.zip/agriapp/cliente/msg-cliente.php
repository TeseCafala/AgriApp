<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'consumer') {
    echo "Acesso negado. Faça login.";
    exit();
}

require_once 'config.php';
date_default_timezone_set('Africa/Luanda'); // Luanda, Angola timezone


$cliente_id = $_SESSION['user_id'];
$agricultor_id = isset($_GET['agricultor_id']) ? intval($_GET['agricultor_id']) : null;

// Mark messages as read if an agricultor_id is present
if ($agricultor_id) {
    $query = "UPDATE mensagens 
              SET status = 'lida' 
              WHERE remetente_id = ? AND destinatario_id = ? AND tipo_remetente = 'agricultor'"; // Only mark farmer messages as read
    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param("ii", $agricultor_id, $cliente_id);
        $stmt->execute();
        $stmt->close();
    } else {
        error_log("Failed to prepare statement for marking messages as read: " . $conn->error);
    }
}

// Send new message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mensagem'], $_POST['agricultor_id'])) {
    $mensagem = trim($_POST['mensagem']);
    $agricultor_id_post = intval($_POST['agricultor_id']);

    if (!empty($mensagem)) {
        $stmt = $conn->prepare("INSERT INTO mensagens (remetente_id, destinatario_id, tipo_remetente, mensagem, status) 
                                 VALUES (?, ?, 'cliente', ?, 'nao_lida')"); // Set initial status to 'nao_lida'
        if ($stmt) {
            $stmt->bind_param("iis", $cliente_id, $agricultor_id_post, $mensagem);
            $stmt->execute();
            $stmt->close();
            header("Location: msg-cliente.php?agricultor_id=$agricultor_id_post");
            exit();
        } else {
            error_log("Failed to prepare statement for sending message: " . $conn->error);
            echo "<p class='error-message'>Erro ao enviar a mensagem. Tente novamente.</p>";
        }
    } else {
        echo "<p class='error-message'>A mensagem não pode estar vazia.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensagens - Cliente</title>
    <link rel="stylesheet" href="msg-cliente.css"> 
</head>
<body>
    <div class="container">
        <h2>Mensagens</h2>
        <div class="sidebar">
            <h4>Agricultores:</h4>
            <ul>
                <?php
                $result = $conn->query("SELECT id, name FROM farmers_ ORDER BY name ASC");
                if ($result) {
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<li><a href='msg-cliente.php?agricultor_id={$row['id']}' class='" . ($agricultor_id == $row['id'] ? 'active-chat' : '') . "'>" . htmlspecialchars($row['name']) . "</a></li>";
                        }
                    } else {
                        echo "<li>Nenhum agricultor encontrado.</li>";
                    }
                    $result->free(); // Free result set
                } else {
                    error_log("Failed to fetch farmers: " . $conn->error);
                    echo "<li>Erro ao carregar agricultores.</li>";
                }
                ?>
            </ul>
        </div>

        <div class="main-content">
            <?php if ($agricultor_id): ?>
                <hr>
                <h4>Conversa com o Agricultor #<?= htmlspecialchars($agricultor_id) ?></h4>
                
                <div class="message-history">
                    <?php
                    $stmt = $conn->prepare(
                        "SELECT remetente_id, destinatario_id, tipo_remetente, mensagem, data_envio, status 
                         FROM mensagens 
                         WHERE (remetente_id = ? AND destinatario_id = ?) 
                           OR (remetente_id = ? AND destinatario_id = ?) 
                         ORDER BY data_envio ASC"
                    );
                    if ($stmt) {
                        $stmt->bind_param("iiii", $cliente_id, $agricultor_id, $agricultor_id, $cliente_id);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            while ($msg = $result->fetch_assoc()):
                                $sender = $msg['tipo_remetente'] === 'cliente' ? 'Você' : 'Agricultor';
                                $message_class = $msg['tipo_remetente'] === 'cliente' ? 'sent-message' : 'received-message';
                                $lida = ($msg['status'] === 'lida') ? '✔️' : '📭'; // Changed to common Unicode characters for better display
                                $data = date('d/m/Y H:i', strtotime($msg['data_envio']));
                                echo "<div class='message-bubble $message_class'>";
                                echo "<p><strong>$sender:</strong> " . htmlspecialchars($msg['mensagem']) . "</p>";
                                echo "<small>Enviado em: $data $lida</small>";
                                echo "</div>";
                            endwhile;
                        } else {
                            echo "<p class='no-messages'>Nenhuma mensagem nesta conversa ainda. Comece a conversar!</p>";
                        }
                        $stmt->close();
                    } else {
                        error_log("Failed to prepare statement for message history: " . $conn->error);
                        echo "<p class='error-message'>Erro ao carregar o histórico de mensagens.</p>";
                    }
                    ?>
                </div>

                <form method="POST" action="msg-cliente.php?agricultor_id=<?= htmlspecialchars($agricultor_id) ?>" class="message-form">
                    <input type="hidden" name="agricultor_id" value="<?= htmlspecialchars($agricultor_id) ?>">
                    <textarea name="mensagem" rows="3" placeholder="Digite sua mensagem..." required></textarea>
                    <button type="submit">Enviar</button>
                </form>
            <?php else: ?>
                <p class="select-message">Selecione um agricultor à esquerda para iniciar uma conversa.</p>
            <?php endif; ?>
        </div>
    </div>
    <div class="navigation-buttons">
        <button onclick="window.history.back()">Voltar</button>
        <a href="produtos.php" class="button">Voltar Para A Dashboard</a>
    </div>
</body>
</html>