<?php
// Include configuration and start session
include 'config.php';
session_start();

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// --- Profile Image Handling ---
$defaultImage = "uploads/default_profile.png";
$stmt = $conn->prepare("SELECT profile_image FROM consumer WHERE id = ?");
if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $profileImage = (!empty($user['profile_image']) && file_exists("uploads/" . $user['profile_image']))
        ? "uploads/" . $user['profile_image']
        : $defaultImage;
} else {
    error_log("Failed to prepare profile image statement: " . $conn->error);
    $profileImage = $defaultImage;
}

// --- Fetch Active Products ---
$sql = "SELECT p.id, p.name, p.description, p.price, p.imagem, p.farmer_id, f.name AS farmer_name 
        FROM productsz p 
        JOIN farmers_ f ON p.farmer_id = f.id 
        WHERE p.ativo = 1 AND f.archived = 0";
$result = mysqli_query($conn, $sql);
$products = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $products[] = $row;
    }
    mysqli_free_result($result);
} else {
    error_log("Error fetching products: " . mysqli_error($conn));
}

// --- NEW CODE FOR UNREAD MESSAGE COUNT ---
$unreadMessageCount = 0;
$stmt_unread_messages = $conn->prepare("SELECT COUNT(*) AS total_unread_messages FROM mensagens WHERE destinatario_id = ? AND tipo_remetente = 'agricultor' AND status = 'nao_lida'");
if ($stmt_unread_messages) {
    $stmt_unread_messages->bind_param("i", $user_id);
    $stmt_unread_messages->execute();
    $result_unread_messages = $stmt_unread_messages->get_result();
    if ($row_unread_messages = $result_unread_messages->fetch_assoc()) {
        $unreadMessageCount = $row_unread_messages['total_unread_messages'];
    }
    $stmt_unread_messages->close();
} else {
    error_log("Failed to prepare statement for unread messages: " . $conn->error);
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Dashboard Loja</title>
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="produtos.css" />
    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.4);
            align-items: center;
            justify-content: center;
            padding: 1rem;
            backdrop-filter: blur(2px);
        }

        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 25px 20px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
            position: relative;
            text-align: center;
            animation: fadeIn 0.3s ease-in-out;
            margin: auto;
        }

        @keyframes fadeIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        .close-modal {
            position: absolute;
            top: 12px;
            right: 15px;
            font-size: 24px;
            color: #888;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close-modal:hover {
            color: #333;
        }

       

        #confirmPaymentBtn {
            margin-top: 20px;
            width: 100%;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: bold;
            background-color: #2E7D32;
            border: none;
            border-radius: 10px;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
            box-shadow: 0 3px 6px rgba(0, 0, 0, 0.08);
        }

        #confirmPaymentBtn:hover {
            background-color: #1B5E20;
        }

        
    </style>
</head>
<body>

<header>
    <div class="nav container">
        <a href="#" class="logo"><span>Agri</span>app</a>
        <input type="text" id="search-input" class="search-box" placeholder="Pesquisar produtos..." />

        <nav class="nav-links">
            <a href="produtos.php" class="nav-item">Início</a>
            <a href="fatura.php" class="nav-item">Atividade</a>
            <a href="msg-cliente.php" class="nav-item">Mensagens</a>
            <a href="cliente_editar_perfil.php" class="nav-item">Editar Perfil</a>
            <a href="agricultores.php" class="nav-item">Agricultores</a>
            <a href="../agricultor/logout.php" class="logout-button">Logout</a>
        </nav>

        <i class='bx bx-shopping-bag' id="cart-icon"></i>

        <div class="profile-container">
            <a href="cliente_editar_perfil.php">
                <img src="<?= htmlspecialchars($profileImage) ?>" alt="Foto de Perfil" class="profile-pic" />
            </a>
        </div>
    </div>
</header>

<div class="cart">
    <h2 class="cart-title">Seu Carrinho</h2>
    <div class="cart-content"></div>
    <div class="total">
        <div class="total-title">Total</div>
        <div class="total-price">Kz 0,00</div>
    </div>
    <button type="button" class="btn-buy">Comprar Agora</button>
    <i class='bx bx-x' id="cart-close"></i>
</div>

<div id="paymentModal" class="modal">
  <div class="modal-content">
    <span class="close-modal">&times;</span>
    <h2>Finalizar Compra</h2>
    <p>Tem certeza que deseja concluir este pedido?</p>
    <button id="confirmPaymentBtn">Confirmar Pedido</button>
  </div>
</div>


<section class="shop container">
    <h2 class="section-title">Produtos Alimentícios</h2>
    <div class="shop-content">
        <?php foreach ($products as $product):
            $imagePath = "../agricultor/uploads/" . htmlspecialchars($product['imagem']);
            if (empty($product['imagem']) || !file_exists($imagePath)) {
                $imagePath = "default.jpg";
            }
        ?>
            <div class="product-box" data-product-id="<?= htmlspecialchars($product['id']) ?>" data-farmer-id="<?= htmlspecialchars($product['farmer_id']) ?>">
                <img src="<?= htmlspecialchars($imagePath) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="product-img" />
                <h2 class="product-title"><?= htmlspecialchars($product['name']) ?></h2>
                <p class="product-description"><?= htmlspecialchars($product['description']) ?></p>
                <span class="product-price">Kz <?= number_format((float)$product['price'], 2, ',', '.') ?></span>
                <i class="bx bx-shopping-bag add-cart"></i>
                <p class="farmer-name">Agric: <?= htmlspecialchars($product['farmer_name']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<script src="produtos.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const searchInput = document.getElementById("search-input");
        const productBoxes = document.querySelectorAll(".product-box");
        searchInput.addEventListener("input", function () {
            const query = searchInput.value.toLowerCase().trim();
            productBoxes.forEach(box => {
                const title = box.querySelector(".product-title").textContent.toLowerCase();
                const desc = box.querySelector(".product-description").textContent.toLowerCase();
                box.style.display = (title.includes(query) || desc.includes(query)) ? "block" : "none";
            });
        });

        <?php if ($unreadMessageCount > 0): ?>
            alert("Você tem <?= $unreadMessageCount ?> novas mensagens!");
        <?php endif; ?>
    });
</script>
</body>
</html>
