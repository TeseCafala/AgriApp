document.addEventListener('DOMContentLoaded', () => {
    const cart = {
        items: [],

        init() {
            this.loadItems();
            this.setupEventListeners();
            this.checkForOrderMessages();
        },

        setupEventListeners() {
            document.querySelector('#cart-icon')?.addEventListener('click', () => {
                document.querySelector('.cart')?.classList.add('active');
            });

            document.querySelector('#cart-close')?.addEventListener('click', () => {
                document.querySelector('.cart')?.classList.remove('active');
            });

            document.querySelectorAll('.add-cart').forEach(btn => {
                btn.addEventListener('click', (e) => this.addItem(e));
            });

            document.querySelector('.btn-buy')?.addEventListener('click', () => {
                if (this.items.length === 0) {
                    alert("Seu carrinho está vazio!");
                    return;
                }
                this.showPaymentModal();
            });

            document.querySelector('.close-modal')?.addEventListener('click', () => {
                document.getElementById('paymentModal').style.display = 'none';
            });

            document.getElementById('confirmPaymentBtn')?.addEventListener('click', async () => {
                await this.processOrder();
            });
        },

        showPaymentModal() {
            const modal = document.getElementById('paymentModal');
            if (!modal) return;
            modal.style.display = 'flex';
        },

        addItem(event) {
            const product = event.target.closest('.product-box');
            if (!product) return;

            const productId = product.dataset.productId || `prod-${Date.now()}`;
            product.dataset.productId = productId;

            if (this.items.some(item => item.productId === productId)) {
                alert('Este item já está no seu carrinho!');
                return;
            }

            const newItem = {
                productId,
                title: product.querySelector('.product-title')?.textContent || 'Produto sem nome',
                price: product.querySelector('.product-price')?.textContent || '0',
                imgSrc: product.querySelector('.product-img')?.src || '',
                farmerId: product.dataset.farmerId || '',
                quantity: 1
            };

            this.items.push(newItem);
            this.renderCartItem(newItem);
            this.saveItems();
            this.updateTotal();

            document.querySelector('.cart')?.classList.add('active');
        },

        renderCartItem(item) {
            const cartContent = document.querySelector('.cart-content');
            const cartBox = document.createElement('div');
            cartBox.className = 'cart-box';
            cartBox.dataset.productId = item.productId;
            cartBox.innerHTML = `
                <img src="${item.imgSrc}" class="cart-img" alt="${item.title}">
                <div class="detail-box">
                    <div class="cart-product-title">${item.title}</div>
                    <div class="cart-price">${item.price}</div>
                    <input type="number" value="${item.quantity}" min="1" class="cart-quantity">
                </div>
                <i class='bx bxs-trash-alt cart-remove'></i>
            `;

            cartBox.querySelector('.cart-remove')?.addEventListener('click', () => this.removeItem(item.productId));
            cartBox.querySelector('.cart-quantity')?.addEventListener('change', (e) => {
                const newQuantity = Math.max(1, parseInt(e.target.value) || 1);
                this.updateQuantity(item.productId, newQuantity);
            });

            cartContent.appendChild(cartBox);
        },

        removeItem(productId) {
            this.items = this.items.filter(item => item.productId !== productId);
            this.saveItems();
            this.updateCartUI();
        },

        updateQuantity(productId, newQuantity) {
            const item = this.items.find(item => item.productId === productId);
            if (item) {
                item.quantity = newQuantity;
                this.saveItems();
                this.updateTotal();
            }
        },

        updateTotal() {
            const totalElement = document.querySelector('.total-price');
            let total = this.items.reduce((sum, item) => {
                const price = parseFloat(item.price.replace(/[^\d.,]/g, '').replace(',', '.'));
                return sum + (isNaN(price) ? 0 : price * item.quantity);
            }, 0);
            totalElement.textContent = `Kz ${total.toFixed(2).replace('.', ',')}`;
        },

        updateCartUI() {
            const cartContent = document.querySelector('.cart-content');
            cartContent.innerHTML = '';
            this.items.forEach(item => this.renderCartItem(item));
            this.updateTotal();
        },

        async processOrder() {
            const confirmBtn = document.getElementById('confirmPaymentBtn');
            try {
                if (this.items.length === 0) throw new Error("Seu carrinho está vazio!");

                const orderData = {
                    items: this.items.map(item => ({
                        product_id: item.productId,
                        farmer_id: item.farmerId,
                        title: item.title,
                        price: parseFloat(item.price.replace(/[^\d.,]/g, '').replace(',', '.')),
                        quantity: item.quantity
                    })),
                    payment_method: "cash",
                    location: null,
                    total_value: this.items.reduce((sum, item) => {
                        const price = parseFloat(item.price.replace(/[^\d.,]/g, '').replace(',', '.'));
                        return sum + (price * item.quantity);
                    }, 0)
                };

                confirmBtn.disabled = true;
                confirmBtn.textContent = 'Processando...';

                const response = await fetch('process_order.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(orderData)
                });

                const rawText = await response.text();
                const contentType = response.headers.get('content-type');

                if (!contentType || !contentType.includes('application/json')) {
                    throw new Error("O servidor retornou dados inválidos. Tente novamente.");
                }

                const result = JSON.parse(rawText);

                if (!response.ok || result.status !== 'success') {
                    throw new Error(result.message || 'Falha ao processar o pedido');
                }

                document.getElementById('paymentModal').style.display = 'none';
                this.clearCart();
                alert(`Pedido #${result.order_id} realizado com sucesso!`);
                if (result.redirect_url) window.location.href = result.redirect_url;

            } catch (error) {
                alert(`Erro: ${error.message}`);
            } finally {
                confirmBtn.disabled = false;
                confirmBtn.textContent = 'Confirmar Pedido';
            }
        },

        checkForOrderMessages() {
            if (new URLSearchParams(window.location.search).has('orderSuccess')) {
                alert('Seu pedido foi realizado com sucesso!');
            }
        },

        clearCart() {
            this.items = [];
            this.saveItems();
            this.updateCartUI();
        },

        saveItems() {
            localStorage.setItem('cartItems', JSON.stringify(this.items));
        },

        loadItems() {
            this.items = JSON.parse(localStorage.getItem('cartItems')) || [];
            this.updateCartUI();
        }
    };

    cart.init();
});
