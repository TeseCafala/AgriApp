<?php
// Database configuration with error handling
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'agriapp');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Enable exceptions for mysqli

try {
    // Create connection (will now throw exceptions if something goes wrong)
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Set charset to prevent encoding issues
    $conn->set_charset("utf8mb4");

    // Set SQL mode (optional but recommended)
    $conn->query("SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO'");
    
    // IMPORTANT: Set the connection's timezone to match Africa/Luanda (UTC+1)
    // This ensures that timestamps stored and retrieved are correctly interpreted
    // relative to the application's timezone.
    $conn->query("SET time_zone = '+01:00'"); // Luanda is UTC+1
    
} catch (mysqli_sql_exception $e) {
    // Log the error securely
    error_log("[" . date('Y-m-d H:i:s') . "] Database Error: " . $e->getMessage());
    
    // Return JSON error if called from API
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        die(json_encode([
            'status' => 'error',
            'message' => 'Service unavailable. Please try again later.'
        ]));
    }
    
    // Simple error for direct access
    die("Service temporarily unavailable. Please try again later.");
}
?>