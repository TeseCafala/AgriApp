<?php
require 'config.php';
session_start();

if (!isset($_SESSION['user_id']) || !isset($_GET['order_id'])) {
    echo "<p>Erro: acesso negado.</p>";
    exit();
}

$order_id = intval($_GET['order_id']);

// Buscar dados do pedido com cliente e agricultor
$sql = "
SELECT p.*, 
       f.name AS farmer_name, f.email AS farmer_email, f.phone AS farmer_phone,
       c.name AS consumer_name, c.email AS consumer_email, c.phone AS consumer_phone, c.delivery_address
FROM pedidos_ p
JOIN farmers_ f ON p.farmer_id = f.id
JOIN consumer c ON p.user_id = c.id
WHERE p.order_id = ? AND p.user_id = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $order_id, $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo "<p>Pedido não encontrado.</p>";
    exit();
}
$order = $result->fetch_assoc();

// Buscar itens do pedido
$sql_items = "
SELECT pr.name, pr.imagem, oi.quantity, oi.price_at_order
FROM order_items oi
JOIN productsz pr ON oi.product_id = pr.id
WHERE oi.order_id = ?
";
$stmt_items = $conn->prepare($sql_items);
$stmt_items->bind_param("i", $order_id);
$stmt_items->execute();
$result_items = $stmt_items->get_result();

// Buscar pagamento
$sql_payment = "SELECT * FROM payments WHERE order_id = ?";
$stmt_pay = $conn->prepare($sql_payment);
$stmt_pay->bind_param("i", $order_id);
$stmt_pay->execute();
$result_pay = $stmt_pay->get_result();
$payment = $result_pay->fetch_assoc();

// Buscar entrega
$sql_delivery = "SELECT * FROM deliveries WHERE id = ?";
$stmt_delivery = $conn->prepare($sql_delivery);
$stmt_delivery->bind_param("i", $order_id); // Ajuste se não for o mesmo ID
$stmt_delivery->execute();
$result_delivery = $stmt_delivery->get_result();
$delivery = $result_delivery->fetch_assoc();
?>

<div class="fatura-detalhes">
    <span class="close-modal" onclick="document.getElementById('modal').style.display='none'">&times;</span>
    <h2>Fatura do Pedido</h2>
    <hr>

    <p><strong>ID do Pedido:</strong> <?= $order['order_id'] ?></p>
    <p><strong>Data do Pedido:</strong> <?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></p>
    <p><strong>Status do Pedido:</strong> <?= htmlspecialchars($order['status']) ?></p>
    <p><strong>Data Criação:</strong> <?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></p>
    <p><strong>Última Atualização:</strong> <?= date('d/m/Y H:i', strtotime($order['updated_at'])) ?></p>
    
    <hr>
    <h3>Dados do Cliente</h3>
    <p><strong>Nome:</strong> <?= htmlspecialchars($order['consumer_name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($order['consumer_email']) ?></p>
    <p><strong>Telefone:</strong> <?= htmlspecialchars($order['consumer_phone']) ?></p>
    <p><strong>Endereço de Entrega:</strong> <?= htmlspecialchars($order['delivery_address']) ?></p>

    <hr>
    <h3>Dados do Agricultor</h3>
    <p><strong>Nome:</strong> <?= htmlspecialchars($order['farmer_name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($order['farmer_email']) ?></p>
    <p><strong>Telefone:</strong> <?= htmlspecialchars($order['farmer_phone']) ?></p>

    <hr>
    <h3>Pagamento</h3>
    <p><strong>Forma de Pagamento:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
    <?php if ($payment): ?>
        <p><strong>Status do Pagamento:</strong> <?= htmlspecialchars($payment['status']) ?></p>
        <p><strong>Data do Pagamento:</strong> <?= date('d/m/Y', strtotime($payment['payment_date'])) ?></p>
        <p><strong>Valor Pago:</strong> <?= number_format($payment['amount'], 2, ',', '.') ?> Kz</p>
        <p><strong>Taxa de Comissão:</strong> <?= $payment['commission_rate'] ?>%</p>
        <?php if ($payment['transfer_date']): ?>
            <p><strong>Data da Transferência:</strong> <?= date('d/m/Y', strtotime($payment['transfer_date'])) ?></p>
        <?php endif; ?>
    <?php else: ?>
        <p><strong>Pagamento:</strong> Ainda não registrado</p>
    <?php endif; ?>

    <?php if ($delivery): ?>
        <hr>
        <h3>Entrega</h3>
        <p><strong>Código de Rastreio:</strong> <?= htmlspecialchars($delivery['tracking_code']) ?></p>
        <p><strong>Data Prevista de Entrega:</strong> <?= date('d/m/Y', strtotime($delivery['delivery_date'])) ?></p>
        <p><strong>Status da Entrega:</strong> <?= htmlspecialchars($delivery['status']) ?></p>
    <?php endif; ?>

    <hr>
    <h3>Itens do Pedido:</h3>
    <table style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background: #f2f2f2;">
                <th>Produto</th>
                <th>Qtd</th>
                <th>Preço Unitário</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($item = $result_items->fetch_assoc()): ?>
                <tr>
                    <td style="padding: 8px;">
                        <?php if ($item['imagem']): ?>
                            <img src="uploads/<?= htmlspecialchars($item['imagem']) ?>" width="40" style="vertical-align: middle; margin-right: 8px;">
                        <?php endif; ?>
                        <?= htmlspecialchars($item['name']) ?>
                    </td>
                    <td style="text-align: center;"><?= $item['quantity'] ?></td>
                    <td style="text-align: right;"><?= number_format($item['price_at_order'], 2, ',', '.') ?> Kz</td>
                    <td style="text-align: right;">
                        <?= number_format($item['price_at_order'] * $item['quantity'], 2, ',', '.') ?> Kz
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<style>
.fatura-detalhes {
    font-family: 'Segoe UI', sans-serif;
    color: #333;
    background: #fff;
    padding: 25px;
    border-radius: 10px;
    max-width: 800px;
    margin: 20px auto;
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
}
.fatura-detalhes h3 {
    color: #2E7D32;
    margin-top: 20px;
}
.fatura-detalhes table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}
.fatura-detalhes th, .fatura-detalhes td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    font-size: 15px;
    text-align: left;
}
.fatura-detalhes th {
    background-color: #f4f4f4;
    font-weight: bold;
}
.fatura-detalhes td:last-child,
.fatura-detalhes th:last-child {
    text-align: right;
}
.fatura-detalhes td:nth-child(2) {
    text-align: center;
}
.close-modal {
    position: absolute;
    top: 12px;
    right: 16px;
    font-size: 22px;
    color: #888;
    cursor: pointer;
}
.close-modal:hover {
    color: #2E7D32;
}
</style>
