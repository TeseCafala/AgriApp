<?php
header('Content-Type: application/json');
require __DIR__ . '/../config.php';

$response = [
    'status' => 'error',
    'message' => '',
    'debug' => []
];

try {
    session_start();
    if (empty($_SESSION['user_id'])) {
        throw new Exception('Usuário não autenticado', 401);
    }
    $response['debug']['user_id'] = $_SESSION['user_id'];

    $jsonInput = file_get_contents('php://input');
    $response['debug']['raw_input'] = $jsonInput;

    $input = json_decode($jsonInput, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('JSON inválido: ' . json_last_error_msg(), 400);
    }

    if (!$input || !is_array($input)) {
        throw new Exception('Dados de entrada inválidos ou vazios', 400);
    }

    $response['debug']['parsed_input'] = $input;

    // Campos obrigatórios
    $requiredFields = ['items', 'payment_method', 'total_value'];
    foreach ($requiredFields as $field) {
        if (!isset($input[$field])) {
            throw new Exception("Campo obrigatório faltando: $field", 400);
        }
    }

    $validPaymentMethods = ['credit_card', 'debit_card', 'paypal', 'cash', 'pix'];
    if (!in_array($input['payment_method'], $validPaymentMethods)) {
        throw new Exception('Método de pagamento inválido. Opções válidas: ' . implode(', ', $validPaymentMethods), 400);
    }

    if (!is_numeric($input['total_value']) || $input['total_value'] <= 0) {
        throw new Exception('Valor total deve ser um número positivo', 400);
    }

    if (!is_array($input['items']) || count($input['items']) === 0) {
        throw new Exception('O pedido deve conter pelo menos um item', 400);
    }

    // Torna location opcional
    $locationData = isset($input['location']) ? $input['location'] : null;
    $response['debug']['location'] = $locationData;

    $conn->begin_transaction();
    $response['debug']['transaction_started'] = true;

    // Pega o primeiro produto para associar ao agricultor
    $productTitle = $input['items'][0]['title'];
    $stmt = $conn->prepare("
        SELECT f.id as farmer_id, p.id as product_id, p.price, p.quantity_avaliable
        FROM farmers_ f 
        INNER JOIN productsz p ON f.id = p.farmer_id 
        WHERE p.name = ? 
        LIMIT 1
    ");
    if (!$stmt) throw new Exception('Erro ao preparar consulta do fazendeiro: ' . $conn->error, 500);

    $stmt->bind_param('s', $productTitle);
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$result->num_rows) throw new Exception("Produto não encontrado: $productTitle", 400);

    $row = $result->fetch_assoc();
    $farmerId = $row['farmer_id'];
    $stmt->close();

    $status = 'Completed';
    $itemCount = count($input['items']);
    $mainProduct = $input['items'][0]['title'];
    if ($itemCount > 1) {
        $mainProduct .= ' +' . ($itemCount - 1);
    }

    $stmt = $conn->prepare("
        INSERT INTO pedidos_ (
            user_id, 
            farmer_id, 
            product_name, 
            total_value, 
            payment_method, 
            status, 
            item_count,
            order_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    if (!$stmt) throw new Exception('Erro ao preparar inserção do pedido: ' . $conn->error, 500);

    $stmt->bind_param(
        'iisdssi',
        $_SESSION['user_id'],
        $farmerId,
        $mainProduct,
        $input['total_value'],
        $input['payment_method'],
        $status,
        $itemCount
    );
    $stmt->execute();
    $orderId = $stmt->insert_id;
    $stmt->close();

    foreach ($input['items'] as $index => $item) {
        if (empty($item['title'])) {
            throw new Exception("Título do produto faltando no item $index", 400);
        }
        if (!isset($item['quantity']) || $item['quantity'] <= 0) {
            throw new Exception("Quantidade inválida para: {$item['title']}", 400);
        }

        $stmt = $conn->prepare("
            SELECT p.id, p.price, p.quantity_avaliable, p.farmer_id
            FROM productsz p 
            WHERE p.name = ?
            FOR UPDATE
        ");
        if (!$stmt) throw new Exception('Erro ao consultar produto: ' . $conn->error, 500);

        $stmt->bind_param('s', $item['title']);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result->num_rows) throw new Exception("Produto não encontrado: {$item['title']}", 400);
        $product = $result->fetch_assoc();
        $stmt->close();

        if ($product['quantity_avaliable'] < $item['quantity']) {
            throw new Exception("Estoque insuficiente: {$item['title']}", 400);
        }

        $stmt = $conn->prepare("
            INSERT INTO order_items (
                order_id, 
                product_id, 
                farmer_id, 
                quantity, 
                price_at_order
            ) VALUES (?, ?, ?, ?, ?)
        ");
        if (!$stmt) throw new Exception('Erro ao inserir item: ' . $conn->error, 500);

        $stmt->bind_param(
            'iiidd',
            $orderId,
            $product['id'],
            $farmerId,
            $item['quantity'],
            $product['price']
        );
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("
            UPDATE productsz 
            SET quantity_avaliable = quantity_avaliable - ? 
            WHERE id = ? AND farmer_id = ?
        ");
        if (!$stmt) throw new Exception('Erro ao atualizar estoque: ' . $conn->error, 500);

        $stmt->bind_param('dii', $item['quantity'], $product['id'], $farmerId);
        $stmt->execute();
        $stmt->close();
    }

    $conn->commit();
    $response = [
        'status' => 'success',
        'message' => 'Pedido criado com sucesso',
        'order_id' => $orderId,
        'payment_method' => $input['payment_method']
    ];

} catch (Exception $e) {
    $conn->rollback();
    http_response_code($e->getCode() ?: 500);
    $response['message'] = $e->getMessage();
    error_log("Order Error: " . $e->getMessage());
    error_log("Trace: " . $e->getTraceAsString());
    error_log("Debug: " . print_r($response['debug'], true));
    if (!in_array($_SERVER['SERVER_NAME'], ['localhost', '127.0.0.1'])) {
        unset($response['debug']);
    }
}

echo json_encode($response);
