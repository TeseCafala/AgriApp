<?php
session_start();
require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$successMessage = "";
$errorMessage = "";

// Buscar dados do usuário
$stmt = $conn->prepare("SELECT name, email, phone, profile_image, password FROM consumer WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = trim($_POST["nome"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $telefone = trim($_POST["telefone"] ?? '');
    $novaSenha = $_POST["nova_senha"] ?? '';
    $profileImage = $userData['profile_image'];

    if (empty($nome) || empty($email) || empty($telefone)) {
        $errorMessage = "Todos os campos obrigatórios devem ser preenchidos.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "E-mail inválido.";
    } elseif (!preg_match("/^[0-9]{7,15}$/", $telefone)) {
        $errorMessage = "Número de telefone inválido.";
    } elseif (!empty($novaSenha) && strlen($novaSenha) < 6) {
        $errorMessage = "A nova senha deve ter pelo menos 6 caracteres.";
    } else {
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
            $ext = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
            $imageName = 'user_' . $userId . '_' . time() . '.' . $ext;
            $uploadDir = __DIR__ . '/uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $uploadDir . $imageName)) {
                $profileImage = $imageName;
            } else {
                $errorMessage = "Erro ao fazer upload da imagem.";
            }
        }

        if (empty($errorMessage)) {
            $senhaFinal = !empty($novaSenha) ? $novaSenha : $userData['password'];
            $stmt = $conn->prepare("UPDATE consumer SET name=?, email=?, phone=?, password=?, profile_image=? WHERE id=?");
            $stmt->bind_param("sssssi", $nome, $email, $telefone, $senhaFinal, $profileImage, $userId);

            if ($stmt->execute()) {
                $successMessage = "Perfil atualizado com sucesso!";
                $userData = [
                    'name' => $nome,
                    'email' => $email,
                    'phone' => $telefone,
                    'profile_image' => $profileImage,
                    'password' => $senhaFinal
                ];
            } else {
                $errorMessage = "Erro ao atualizar perfil.";
            }
            $stmt->close();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .container {
    max-width: 480px;
    background: #fff;
    margin: 30px auto;
    padding: 25px 20px;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    max-height: 92vh; /* limite de altura da tela */
    overflow-y: auto; /* rola internamente se ultrapassar */
}


        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2E7D32;
        }

        form label {
            font-weight: bold;
            margin-top: 15px;
            display: block;
            color: #444;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            background: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            margin-top: 20px;
            cursor: pointer;
            transition: background 0.3s;
        }

        input[type="submit"]:hover {
            background: #2E7D32;
        }

        .msg {
    padding: 10px;
    border-radius: 6px;
    margin-bottom: 15px;
    font-size: 14px;
}

        .success {
            background: #d4edda;
            color: #155724;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
        }

        img {
            display: block;
            margin: 0 auto 15px;
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #2E7D32;
        }

        .no-photo {
            text-align: center;
            color: #777;
            margin-bottom: 15px;
        }

        a.back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #2E7D32;
            font-weight: bold;
        }

        a.back-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 520px) {
            .container {
                margin: 30px 16px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Editar Perfil</h2>

    <?php if (!empty($successMessage)): ?>
        <div class="msg success"><?= htmlspecialchars($successMessage) ?></div>
    <?php elseif (!empty($errorMessage)): ?>
        <div class="msg error"><?= htmlspecialchars($errorMessage) ?></div>
    <?php endif; ?>

    <?php if (!empty($userData['profile_image'])): ?>
        <img src="uploads/<?= htmlspecialchars($userData['profile_image']) ?>" alt="Foto de Perfil">
    <?php else: ?>
        <div class="no-photo">Sem foto de perfil</div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome" value="<?= htmlspecialchars($userData['name']) ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?= htmlspecialchars($userData['email']) ?>" required>

        <label for="telefone">Telefone:</label>
        <input type="text" name="telefone" id="telefone" value="<?= htmlspecialchars($userData['phone']) ?>" required>

        <label for="nova_senha">Nova Senha (opcional):</label>
        <input type="password" name="nova_senha" id="nova_senha">

        <label for="profile_image">Foto de Perfil:</label>
        <input type="file" name="profile_image" id="profile_image" accept="image/*">

        <input type="submit" value="Atualizar Perfil">
    </form>

    <a href="produtos.php" class="back-link">← Voltar ao Dashboard</a>
</div>
</body>
</html>
