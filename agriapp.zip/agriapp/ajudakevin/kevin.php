<!DOCTYPE html>
<html lang="pt-pt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Farmer Dashboard</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        html, body {
            height: 100%;
            scroll-behavior: smooth;
        }

        body {
            background-color: var(--primary-color-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1280px;
            margin: auto;
            padding: 20px;
        }

        /* Header */
        header {
            width: 100%;
            padding: 20px 4%;
            position: fixed;
            top: 0;
            left: 0;
            transition: all 0.5s ease;
            background: rgba(95, 133, 117, 0.9); /* Verde agrícola com transparência */
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header.rolagem {
            background-color: var(--primary-color-dark); /* Verde escuro */
            padding: 10px 4%;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        header .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--white);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        header .logo i {
            font-size: 2rem;
        }

        header nav ul {
            list-style: none;
            display: flex;
            gap: 30px;
        }

        header nav ul li a {
            color: var(--white);
            text-decoration: none;
            font-size: 1rem;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        header nav ul li a:hover {
            color: var(--primary-color); /* Verde agrícola */
        }

        header .search-bar {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        header .search-bar input {
            padding: 10px;
            border: none;
            border-radius: 25px;
            outline: none;
            font-size: 1rem;
            width: 250px;
        }

        header .search-bar button {
            padding: 10px 20px;
            font-size: 1rem;
            background-color: var(--primary-color); /* Verde agrícola */
            border: none;
            border-radius: 25px;
            color: var(--white);
            cursor: pointer;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        header .search-bar button:hover {
            background-color: var(--primary-color-dark); /* Verde escuro */
            transform: translateY(-3px);
        }

        /* Hero Section */
        .hero {
            height: 100vh;
            background: url('./imagens/agriculturaimagem.jpeg') center/cover no-repeat;

            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            color: var(--white);
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
        }

        .hero::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            z-index: 1;
        }

        .hero h1 {
            font-size: 4.5rem;
            text-align: center;
            z-index: 2;
        }

        /* Dashboard Stats */
        .dashboard-stats {
            display: flex;
            justify-content: space-around;
            padding: 50px 20px;
            background-color: var(--white);
            margin-top: 50px;
        }

        .dashboard-stats .stat {
            text-align: center;
        }

        .dashboard-stats .stat h2 {
            font-size: 40px;
            color: var(--primary-color); /* Verde agrícola */
        }

        .dashboard-stats .stat p {
            font-size: 18px;
            color: var(--text-dark);
        }

        /* Featured Products */
        .featured-products {
            padding: 50px 20px;
            background-color: var(--primary-color-light); /* Fundo claro */
        }

        .featured-products h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: var(--text-dark);
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .product-card {
            background: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .product-card:hover {
            transform: translateY(-10px);
        }

        .product-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .product-card .product-info {
            padding: 20px;
        }

        .product-card h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--text-dark);
        }

        .product-card p {
            font-size: 1rem;
            color: var(--text-light);
        }

        /* Footer */
        footer {
            background: var(--primary-color-dark); /* Verde escuro */
            color: var(--white);
            padding: 80px 40px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 60px;
        }

        footer .footer-section {
            flex: 1 1 200px;
            min-width: 250px;
        }

        footer .footer-logo {
            font-size: 2.5rem;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 20px;
        }

        footer .footer-links, footer .footer-contact {
            margin-top: 20px;
            line-height: 2;
        }

        footer .social-icons {
            display: flex;
            gap: 15px;
        }

        footer .social-icons a {
            font-size: 1.5rem;
            background: var(--primary-color); /* Verde agrícola */
            color: var(--white);
            padding: 10px;
            border-radius: 50%;
            transition: transform 0.3s ease, background 0.3s ease;
        }

        footer .social-icons a:hover {
            background: var(--white);
            color: var(--primary-color); /* Verde agrícola */
            transform: scale(1.2);
        }

        @media (max-width: 768px) {
            header nav ul {
                flex-direction: column;
                gap: 15px;
            }

            .hero h1 {
                font-size: 3rem;
            }

            .dashboard-stats {
                flex-direction: column;
                gap: 30px;
            }

            .product-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header id="Cabecalho">
        <div class="logo">
            <i class="bi bi-globe-europe-africa"></i>
            <span>Agriapp</span>
        </div>
        <nav>
            <ul>
                <li><a href="dashboard.html">Inicio</a></li>
                <li><a href="produtos.html">Produtos</a></li>
                <li><a href="transaçoes.html">Transações</a></li>
                <li><a href="editar.html">Editar</a></li>
            </ul>
        </nav>
        <div class="search-bar">
            <input type="text" placeholder="Pesquisar produtos...">
            <button><i class="bi bi-search"></i></button>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <h1>Bem-vindo ao <span>Agriapp</span></h1>

    </section>

    <!-- Dashboard Stats -->
    <div class="dashboard-stats">
        <div class="stat">
            <h2>1,200</h2>
            <p>Produtos Vendidos</p>
        </div>
        <div class="stat">
            <h2>500</h2>
            <p>Clientes Satisfeitos</p>
        </div>
        <div class="stat">
            <h2>R$ 50,000</h2>
            <p>Receita Total</p>
        </div>
    </div>

    <!-- Featured Products -->
    <section class="featured-products">
        <h2>Produtos em Destaque</h2>
        <div class="product-grid">
            <div class="product-card">
                <img src="https://via.placeholder.com/300" alt="Produto 1">
                <div class="product-info">
                    <h3>Tomate Orgânico</h3>
                    <p>Tomates frescos e orgânicos, cultivados sem agrotóxicos.</p>
                </div>
            </div>
            <div class="product-card">
                <img src="https://via.placeholder.com/300" alt="Produto 2">
                <div class="product-info">
                    <h3>Batata Doce</h3>
                    <p>Batata doce rica em nutrientes, ideal para uma alimentação saudável.</p>
                </div>
            </div>
            <div class="product-card">
                <img src="https://via.placeholder.com/300" alt="Produto 3">
                <div class="product-info">
                    <h3>Maçãs Vermelhas</h3>
                    <p>Maçãs vermelhas suculentas, colhidas diretamente do pomar.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-section">
            <div class="footer-logo">Agriapp</div>
            <p>Transformando a agricultura com tecnologia e inovação para um futuro sustentável.</p>
        </div>
        <div class="footer-section">
            <h3>Contato</h3>
            <p>Email: contato@agriapp.com</p>
            <p>Telefone: +55 123 456 789</p>
        </div>
        <div class="footer-section">
            <h3>Redes Sociais</h3>
            <div class="social-icons">
                <a href="https://www.facebook.com" target="_blank"><i class="bi bi-facebook"></i></a>
                <a href="https://www.instagram.com" target="_blank"><i class="bi bi-instagram"></i></a>
                <a href="https://www.twitter.com" target="_blank"><i class="bi bi-twitter"></i></a>
            </div>
        </div>
    </footer>

    <script>
        // JavaScript for header scroll effect
        window.addEventListener("scroll", function() {
            const header = document.querySelector("header");
            header.classList.toggle("rolagem", window.scrollY > 0);
        });
    </script>
</body>
</html>