window.addEventListener("scroll", function()
{
    let header = document.querySelector('#Cabecalho');
    header.classList.toggle('rolagem', window.scrollY > 0) //Adicionar uma classe de forma dinamica ao header 
} //Escutador de eventos, evento de scroll 
)